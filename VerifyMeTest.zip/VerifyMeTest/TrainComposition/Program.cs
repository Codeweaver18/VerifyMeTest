﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainComposition
{
    public class Program
    {
        static void Main(string[] args)
        {
            TrainComparison.PreLoadwagonList(new int[] {7, 13, 4, 5,6,7, 6,9});
            //attaching test
            TrainComparison.attachLeft(10);
            TrainComparison.attachRight(20);
            //detached test
            TrainComparison.detachLeft();
            TrainComparison.detachRight();
            TrainComparison.detachLeft();
            TrainComparison.detachRight();
            TrainComparison.detachLeft();
            TrainComparison.detachRight();
            Console.ReadLine();

        }
    }

    public static class TrainComparison
    {
        public static List<int> wagonList = new List<int>();
        
       public static void PreLoadwagonList(int [] array)
        {
            //just to preload Items for test purposes;
            foreach (var item in array)
            {
                wagonList.Add(item);
            }

            Console.WriteLine("list of default/preset Waggons ::");
            foreach (var item in wagonList)
            {
                Console.WriteLine(item);

            }
        }
        public static void attachRight(int wagonNumber)
        {
            wagonList.Add(wagonNumber);
            Console.WriteLine("List of wagon are as follows after adding" +$"{ wagonNumber}::from the right");
            try
            {
                foreach (var item in wagonList)
                {
                    Console.WriteLine(item);
                    
                }
            }
            catch (Exception ex)
            {

                //you can decide to do something with your exception eg.g log or throw it
            }
        }

        public static void attachLeft(int wagonNumber)
        {
            try
            {
                if (wagonList.Count > 1)
                {
                    var reverseList = wagonList;
                    reverseList.Reverse();
                    reverseList.Add(wagonNumber);
                    reverseList.Reverse();
                    wagonList = reverseList;
                }
                Console.WriteLine("List of wagon are as follows after adding" +$"{wagonNumber}:: from the left");
                foreach (var item in wagonList)
                {
                    Console.WriteLine(item);
                   
                }
            }
            catch (Exception ex)
            {

                //you can decide to do something with your exception eg.g log or throw it
            }
        }

        public static void detachLeft()
        {
            try
            {
                if (wagonList.Count>1)
                {
                    wagonList.RemoveAt(0);
                }

                Console.WriteLine("List of wagon are as follows  after detaching from the left::");
                foreach (var item in wagonList)
                {
                    Console.WriteLine(item);
                    
                }
            }
            catch (Exception ex)
            {

                //you can decide to do something with your exception eg.g log or throw it
            }
        }

        public static void detachRight()
        {
            try
            {
                if (wagonList.Count > 1)
                {
                    wagonList.RemoveAt(wagonList.Count-1);
                }

                Console.WriteLine("List of wagon are as follows after detaching from the right::");
                foreach (var item in wagonList)
                {
                    Console.WriteLine(item);
                   
                }
            }
            catch (Exception ex)
            {

                //you can decide to do something with your exception eg.g log or throw it
            }
        }
    }
}

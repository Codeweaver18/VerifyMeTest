﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberCount
{
    public class Program
    {
        static void Main(string[] args)
        {
            _countNumber(new int[] { 1, 3, 5, 7}, 4);
        }

        //<summary>
        //This implementation is based on the fact  that the array has been sorted and the array length is given as parameter;
        //</summary>
        public static void _countNumber(int[] sortedArray, int lessThan)
        {
            var LessthanCount = 0;
            bool isError = false;
            Stopwatch sw = new Stopwatch();// initiating timer
            try
            {
                sw.Restart();
                foreach (var item in sortedArray)
                {
                    if (item<lessThan)
                    {
                        LessthanCount++;
                    }
                }
                sw.Stop();
            }
            catch (Exception ex)
            {
                isError = true;
                //in a real Enterprise applications, you might want to make a good use of your error; probably throw it or log it;
                
            }

            finally
            {
                if (!isError)
                {
                    Console.WriteLine("Number of elements less than" + $"{lessThan} is {LessthanCount}");
                    Console.WriteLine("Total time taking is " + $"{sw.Elapsed}");
                    Console.ReadLine();
                }

                else
                {
                    Console.WriteLine("oops an error has occured your program might not have run correctly");
                    Console.WriteLine("Number of elements less than" + $"{lessThan} is {LessthanCount}");
                    Console.ReadLine();
                }
              
                
            }
        }
        //<summary>
        //This implementation is based on the fact  that the array is not  sorted and the array length is derived from the array.length;
        //</summary>
        public static void _countNumber(int[] unsortedArray)
        {
            var LessthanCount = 0;
            bool isError = false;
            var sortedArray = new int[unsortedArray.Length];
            Array.Copy(unsortedArray, sortedArray, unsortedArray.Length);
            Array.Sort(sortedArray);
            var lessThan = sortedArray.Length;
            Stopwatch sw = new Stopwatch();// initiating timer
            try
            {
                sw.Restart();
                foreach (var item in sortedArray)
                {
                    if (item < lessThan)
                    {
                        LessthanCount++;
                    }
                }
                sw.Stop();
            }
            catch (Exception ex)
            {
                isError = true;
                //in a real Enterprise applications, you might want to make a good use of your error; probably throw it or log it;

            }

            finally
            {
                if (!isError)
                {
                    Console.WriteLine("Number of elements less than" + $"{lessThan} is {LessthanCount}");
                    Console.WriteLine("Total time taking is " + $"{sw.Elapsed}");
                    Console.ReadLine();
                }

                else
                {
                    Console.WriteLine("oops an error has occured your program might not have run correctly");
                    Console.WriteLine("Number of elements less than" + $"{lessThan} is {LessthanCount}");
                    Console.ReadLine();
                }


            }
        }
    }

    
}
